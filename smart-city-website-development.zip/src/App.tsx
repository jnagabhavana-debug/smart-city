import TopBar from "./components/TopBar";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Ticker from "./components/Ticker";
import Stats from "./components/Stats";
import Transportation from "./components/Transportation";
import Healthcare from "./components/Healthcare";
import Education from "./components/Education";
import Services from "./components/Services";
import Emergency from "./components/Emergency";
import Locations from "./components/Locations";
import News from "./components/News";
import Footer from "./components/Footer";
import Assistant from "./components/Assistant";
import { useRevealRoot } from "./hooks/useReveal";

export default function App() {
  useRevealRoot();
  return (
    <div className="min-h-screen bg-[#050914] text-slate-200 antialiased">
      <TopBar />
      <Navbar />
      <main>
        <Hero />
        <Ticker />
        <Stats />
        <div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" /></div>
        <Transportation />
        <div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" /></div>
        <Healthcare />
        <div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" /></div>
        <Education />
        <div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" /></div>
        <Services />
        <Emergency />
        <Locations />
        <div className="mx-auto max-w-7xl px-4 sm:px-6"><div className="h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" /></div>
        <News />
      </main>
      <Footer />
      <Assistant />
    </div>
  );
}
