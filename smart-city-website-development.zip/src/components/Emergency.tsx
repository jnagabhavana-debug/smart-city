import { useState } from "react";
import { Siren, ShieldCheck, Flame, HeartPulse, TriangleAlert, Heart, Globe, Phone, MapPin, BellRing, LifeBuoy, ChevronRight } from "lucide-react";
import { emergencyContacts, incidents } from "../data/cityData";

const iconMap: Record<string, any> = { shield: ShieldCheck, flame: Flame, cross: HeartPulse, alert: TriangleAlert, heart: Heart, globe: Globe };

export default function Emergency() {
  const [sos, setSos] = useState(false);
  const [sosStep, setSosStep] = useState(0);

  const triggerSOS = () => {
    setSos(true);
    setSosStep(1);
    setTimeout(() => setSosStep(2), 1400);
    setTimeout(() => setSosStep(3), 2800);
  };

  return (
    <section id="emergency" className="relative overflow-hidden py-20">
      {/* dramatic bg */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#16060c] via-[#0d0714] to-[#050914]" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-red-500/60 to-transparent" />
      <div className="pointer-events-none absolute -left-24 top-1/3 h-96 w-96 rounded-full bg-red-600/15 blur-3xl" />
      <div className="pointer-events-none absolute -right-24 top-10 h-96 w-96 rounded-full bg-orange-500/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono2 flex items-center gap-2 text-xs tracking-[0.25em] text-red-300"><span className="animate-pulse-dot h-2 w-2 rounded-full bg-red-400" /> 06 · EMERGENCY & SAFETY</p>
            <h2 className="font-display mt-2 text-3xl font-bold text-white sm:text-4xl">Help is always <span className="text-red-400">90 seconds</span> away</h2>
            <p className="mt-2 max-w-xl text-slate-400">Unified 911 dispatch · 42 response stations · drone first-responders · average arrival 6 min 20 sec.</p>
          </div>
          <div className="glass flex items-center gap-3 rounded-2xl px-4 py-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-400/15"><ShieldCheck className="h-5 w-5 text-emerald-300" /></span>
            <div><p className="text-sm font-bold text-white">City threat level: <span className="text-emerald-300">LOW</span></p><p className="text-xs text-slate-400">No active citywide advisories</p></div>
          </div>
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[380px_1fr]">
          {/* SOS panel */}
          <div className="reveal relative overflow-hidden rounded-3xl border border-red-500/30 bg-gradient-to-b from-red-950/60 to-[#0a0a1c] p-6">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-red-500 via-orange-400 to-red-500" />
            <div className="flex items-center gap-2">
              <Siren className="h-5 w-5 text-red-400" />
              <p className="font-mono2 text-xs tracking-[0.2em] text-red-300">ONE-TAP SOS</p>
            </div>
            {!sos ? (
              <>
                <h3 className="font-display mt-3 text-2xl font-bold text-white">In danger? Press & hold SOS.</h3>
                <p className="mt-2 text-sm text-slate-400">Shares your live GPS with the nearest dispatch unit + 3 emergency contacts instantly.</p>
                <button onClick={triggerSOS} className="group relative mx-auto mt-6 flex h-40 w-40 items-center justify-center rounded-full bg-gradient-to-b from-red-500 to-red-700 font-display text-3xl font-bold text-white shadow-[0_0_60px_-10px_rgba(239,68,68,0.8)] transition hover:scale-105 active:scale-95">
                  <span className="absolute inset-2 rounded-full border-2 border-white/20" />
                  <span className="absolute inset-0 animate-ping rounded-full bg-red-500/20" />
                  SOS
                </button>
                <div className="mt-6 grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl bg-white/5 p-3"><p className="font-bold text-white">42 stations</p><p className="text-slate-400">under 2km apart</p></div>
                  <div className="rounded-xl bg-white/5 p-3"><p className="font-bold text-white">6:20 avg</p><p className="text-slate-400">response time</p></div>
                </div>
              </>
            ) : (
              <div className="mt-4 rounded-2xl border border-red-400/30 bg-black/40 p-5">
                <div className="flex items-center gap-2 text-red-300"><span className="animate-pulse-dot h-2.5 w-2.5 rounded-full bg-red-400" /><p className="font-mono2 text-xs font-bold tracking-widest">SOS ACTIVE — STAY CALM</p></div>
                <div className="mt-4 space-y-3 text-sm">
                  <div className={`flex items-center gap-2.5 ${sosStep >= 1 ? "text-white" : "text-slate-600"}`}><span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${sosStep >= 1 ? "bg-red-500 text-white" : "bg-white/10"}`}>1</span> Locating you via GPS… {sosStep >= 1 && <span className="text-emerald-300">✓ Central Hub</span>}</div>
                  <div className={`flex items-center gap-2.5 ${sosStep >= 2 ? "text-white" : "text-slate-600"}`}><span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${sosStep >= 2 ? "bg-red-500 text-white" : "bg-white/10"}`}>2</span> Alerting nearest unit… {sosStep >= 2 && <span className="text-emerald-300">✓ Unit R-17 dispatched</span>}</div>
                  <div className={`flex items-center gap-2.5 ${sosStep >= 3 ? "text-white" : "text-slate-600"}`}><span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${sosStep >= 3 ? "bg-red-500 text-white" : "bg-white/10"}`}>3</span> Notifying contacts… {sosStep >= 3 && <span className="text-emerald-300">✓ 3 contacts pinged</span>}</div>
                </div>
                {sosStep >= 3 && (
                  <div className="mt-4 rounded-xl bg-emerald-400/10 p-3 text-xs text-emerald-200 ring-1 ring-emerald-400/30">
                    Help is on the way — Unit R-17 arriving in ~4 min. Keep your phone on. Dispatch: +1 (555) 010-0911
                  </div>
                )}
                <button onClick={() => { setSos(false); setSosStep(0); }} className="mt-4 w-full rounded-xl bg-white/10 py-2.5 text-sm font-bold text-white hover:bg-white/15">Cancel demo SOS</button>
              </div>
            )}
          </div>

          <div>
            {/* contacts */}
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
              {emergencyContacts.map((c, i) => {
                const Icon = iconMap[c.icon];
                return (
                  <a key={c.name} href={`tel:${c.number}`} className={`reveal ${i % 3 === 1 ? "reveal-delay-1" : i % 3 === 2 ? "reveal-delay-2" : ""} glass card-glow group rounded-2xl p-4`}>
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: `${c.color}22` }}><Icon className="h-5 w-5" style={{ color: c.color }} /></span>
                    <p className="font-display mt-2.5 text-2xl font-bold text-white group-hover:text-red-200">{c.number}</p>
                    <p className="text-[13px] font-bold text-slate-200">{c.name}</p>
                    <p className="text-[11px] text-slate-500">{c.desc}</p>
                  </a>
                );
              })}
            </div>

            {/* incident feed */}
            <div className="reveal glass mt-4 rounded-3xl p-5">
              <div className="flex items-center justify-between">
                <p className="flex items-center gap-2 text-sm font-bold text-white"><BellRing className="h-4 w-4 text-amber-300" /> Live incident feed</p>
                <span className="font-mono2 text-[11px] text-slate-500">UPDATED 12 SEC AGO</span>
              </div>
              <div className="mt-3 space-y-2">
                {incidents.map((n) => (
                  <div key={n.id} className="flex flex-wrap items-center gap-3 rounded-2xl bg-white/[0.03] px-4 py-3 ring-1 ring-white/5">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: n.color }} />
                    <span className="font-mono2 text-xs font-bold text-slate-400">{n.id}</span>
                    <span className="rounded-md bg-white/10 px-2 py-0.5 text-[11px] font-bold text-white">{n.type}</span>
                    <span className="flex items-center gap-1 text-[13px] text-slate-300"><MapPin className="h-3 w-3" /> {n.location}</span>
                    <span className="ml-auto flex items-center gap-2 text-xs">
                      <span className="text-slate-500">{n.time}</span>
                      <span className="rounded-full px-2.5 py-1 font-bold" style={{ background: `${n.color}1e`, color: n.color }}>{n.status}</span>
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-4 grid gap-2 sm:grid-cols-3">
                {[
                  { icon: LifeBuoy, t: "Flood shelters", d: "18 sites · nearest 0.6km" },
                  { icon: Flame, t: "Fire safety drills", d: "Every first Sunday" },
                  { icon: Phone, t: "Report incident", d: "Photo + GPS in app" },
                ].map((x) => (
                  <button key={x.t} className="flex items-center gap-2.5 rounded-2xl bg-white/[0.04] p-3 text-left transition hover:bg-white/[0.07]">
                    <x.icon className="h-5 w-5 shrink-0 text-red-300" />
                    <span><span className="block text-[13px] font-bold text-white">{x.t}</span><span className="block text-[11px] text-slate-400">{x.d}</span></span>
                    <ChevronRight className="ml-auto h-4 w-4 text-slate-500" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
