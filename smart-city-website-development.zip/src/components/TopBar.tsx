import { useEffect, useState } from "react";
import { CloudSun, Wind, Droplets, Thermometer, Siren } from "lucide-react";

export default function TopBar() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const fmt = time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const date = time.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  return (
    <div className="relative z-[60] hidden border-b border-white/10 bg-[#04081a]/95 backdrop-blur-md md:block">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-1.5 text-[12px]">
        <div className="flex items-center gap-5 text-slate-300">
          <span className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            <span className="font-mono2 font-medium tracking-wide text-emerald-300">ALL SYSTEMS OPERATIONAL</span>
          </span>
          <span className="hidden items-center gap-1.5 lg:flex"><CloudSun className="h-3.5 w-3.5 text-amber-300" /> 24°C Sunny</span>
          <span className="hidden items-center gap-1.5 lg:flex"><Wind className="h-3.5 w-3.5 text-cyan-300" /> AQI 32 · Good</span>
          <span className="hidden items-center gap-1.5 xl:flex"><Droplets className="h-3.5 w-3.5 text-sky-300" /> Humidity 54%</span>
          <span className="hidden items-center gap-1.5 xl:flex"><Thermometer className="h-3.5 w-3.5 text-rose-300" /> Feels 26°C</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="font-mono2 text-slate-400">{date} · <span className="text-cyan-300">{fmt}</span> NPT</span>
          <a href="#emergency" className="flex items-center gap-1.5 rounded-full bg-red-500/15 px-3 py-1 font-semibold text-red-300 ring-1 ring-red-500/40 transition hover:bg-red-500/30">
            <Siren className="h-3.5 w-3.5" /> Emergency: 911
          </a>
        </div>
      </div>
    </div>
  );
}
