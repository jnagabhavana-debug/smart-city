import { Megaphone } from "lucide-react";
import { tickerAlerts } from "../data/cityData";

export default function Ticker() {
  const items = [...tickerAlerts, ...tickerAlerts];
  return (
    <div className="relative z-10 border-y border-white/10 bg-[#070d22]/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center">
        <div className="z-10 flex shrink-0 items-center gap-2 bg-gradient-to-r from-cyan-500 to-sky-600 px-4 py-3 text-[12px] font-bold uppercase tracking-wider text-white">
          <Megaphone className="h-4 w-4" /> <span className="hidden sm:inline">Live Wire</span>
        </div>
        <div className="relative flex-1 overflow-hidden py-3">
          <div className="animate-marquee flex w-max items-center gap-10 whitespace-nowrap px-6">
            {items.map((a, i) => (
              <span key={i} className="flex items-center gap-2 text-[13px] text-slate-300">
                <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wider ${
                  a.tone === "amber" ? "bg-amber-400/15 text-amber-300" : a.tone === "green" ? "bg-emerald-400/15 text-emerald-300" : "bg-cyan-400/15 text-cyan-300"
                }`}>{a.tag}</span>
                {a.text}
                <span className="ml-6 h-1 w-1 rounded-full bg-slate-600" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
