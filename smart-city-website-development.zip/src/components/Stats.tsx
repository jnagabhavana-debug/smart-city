import { useEffect, useRef, useState } from "react";
import { Users, Leaf, TrainFront, Zap, ShieldCheck, Wifi, TrendingUp, BarChart3 } from "lucide-react";
import { cityStats, populationGrowth, energyMix, trafficByHour } from "../data/cityData";

const iconMap: Record<string, any> = { users: Users, leaf: Leaf, train: TrainFront, zap: Zap, shield: ShieldCheck, wifi: Wifi };

function Counter({ target, suffix, duration = 1600 }: { target: number; suffix: string; duration?: number }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !started.current) {
        started.current = true;
        const t0 = performance.now();
        const tick = (t: number) => {
          const p = Math.min((t - t0) / duration, 1);
          const eased = 1 - Math.pow(1 - p, 3);
          setVal(Math.round(target * eased));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.4 });
    obs.observe(el);
    return () => obs.disconnect();
  }, [target, duration]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

export default function Stats() {
  const maxPop = Math.max(...populationGrowth.map((d) => d.pop));
  const maxTraffic = Math.max(...trafficByHour.map((d) => d.v));
  // donut
  const R = 54;
  const C = 2 * Math.PI * R;
  let acc = 0;

  return (
    <section id="stats" className="relative py-20">
      <div className="pointer-events-none absolute left-1/2 top-0 h-72 w-[720px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono2 text-xs tracking-[0.25em] text-cyan-300">01 · CITY INTELLIGENCE</p>
            <h2 className="font-display mt-2 text-3xl font-bold text-white sm:text-4xl">Novapolis in numbers</h2>
            <p className="mt-2 max-w-xl text-slate-400">Real-time indicators streamed from 40,000+ IoT sensors across 12 districts — refreshed every 60 seconds.</p>
          </div>
          <div className="glass flex items-center gap-3 rounded-2xl px-4 py-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-400/15"><TrendingUp className="h-5 w-5 text-emerald-300" /></span>
            <div>
              <p className="font-display text-xl font-bold text-white">98.2<span className="text-sm text-slate-400">/100</span></p>
              <p className="text-xs text-slate-400">Liveability score · #3 world</p>
            </div>
          </div>
        </div>

        {/* counters */}
        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
          {cityStats.map((s, i) => {
            const Icon = iconMap[s.icon];
            const isPop = s.label === "Population";
            return (
              <div key={s.label} className={`reveal ${i % 3 === 1 ? "reveal-delay-1" : i % 3 === 2 ? "reveal-delay-2" : ""} glass card-glow group rounded-2xl p-5`}>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/25 to-violet-500/25 ring-1 ring-white/10 transition group-hover:from-cyan-400/40">
                  <Icon className="h-5 w-5 text-cyan-300" />
                </span>
                <p className="font-display mt-3 text-[26px] font-bold leading-none text-white">
                  {isPop ? <Counter target={2485000} suffix="" /> : <Counter target={s.value} suffix={s.suffix} />}
                </p>
                <p className="mt-1.5 text-[13px] font-semibold text-slate-200">{s.label}</p>
                <p className="text-[11px] text-slate-500">{s.sub}</p>
              </div>
            );
          })}
        </div>

        {/* charts row */}
        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {/* population */}
          <div className="reveal glass rounded-3xl p-6 lg:col-span-1">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Population growth</h3>
              <span className="rounded-full bg-cyan-400/10 px-2.5 py-1 text-[11px] font-bold text-cyan-300">MILLIONS</span>
            </div>
            <div className="mt-5 flex h-44 items-end gap-2">
              {populationGrowth.map((d) => (
                <div key={d.year} className="group flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-[10px] font-bold text-cyan-200 opacity-0 transition group-hover:opacity-100">{d.pop}M</span>
                  <div className="flex w-full flex-1 items-end rounded-lg bg-white/5">
                    <div className="w-full rounded-lg bg-gradient-to-t from-cyan-600 to-cyan-300 transition-all duration-700 group-hover:from-violet-600 group-hover:to-violet-300" style={{ height: `${(d.pop / maxPop) * 100}%` }} />
                  </div>
                  <span className="font-mono2 text-[10px] text-slate-500">{d.year.slice(2)}</span>
                </div>
              ))}
            </div>
            <p className="mt-4 rounded-xl bg-white/[0.04] p-3 text-xs leading-relaxed text-slate-400"><span className="font-bold text-emerald-300">+36% since 2018.</span> Fastest-growing smart corridor in the region, driven by Tech Park & Harborfront housing.</p>
          </div>

          {/* energy donut */}
          <div className="reveal reveal-delay-1 glass rounded-3xl p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Energy mix · live</h3>
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-400/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300"><span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" /> 78% GREEN</span>
            </div>
            <div className="mt-4 flex items-center gap-5">
              <div className="relative h-40 w-40 shrink-0">
                <svg viewBox="0 0 140 140" className="h-full w-full -rotate-90">
                  <circle cx="70" cy="70" r={R} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="16" />
                  {energyMix.map((e) => {
                    const frac = e.value / 100;
                    const dash = frac * C;
                    const gap = C - dash;
                    const offset = -acc * C;
                    acc += frac;
                    return <circle key={e.label} cx="70" cy="70" r={R} fill="none" stroke={e.color} strokeWidth="16" strokeDasharray={`${dash} ${gap}`} strokeDashoffset={offset} strokeLinecap="butt" />;
                  })}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <p className="font-display text-2xl font-bold text-white">1.2<span className="text-sm text-slate-400">GW</span></p>
                  <p className="text-[10px] uppercase tracking-wider text-slate-500">demand now</p>
                </div>
              </div>
              <div className="flex-1 space-y-2">
                {energyMix.map((e) => (
                  <div key={e.label} className="flex items-center gap-2 text-xs">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: e.color }} />
                    <span className="font-medium text-slate-300">{e.label}</span>
                    <span className="ml-auto font-mono2 font-bold text-white">{e.value}%</span>
                  </div>
                ))}
              </div>
            </div>
            <p className="mt-4 rounded-xl bg-white/[0.04] p-3 text-xs leading-relaxed text-slate-400">Solar peak 11AM–2PM powers <span className="font-bold text-amber-300">62% of metro traction</span> directly.</p>
          </div>

          {/* traffic */}
          <div className="reveal reveal-delay-2 glass rounded-3xl p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display flex items-center gap-2 text-lg font-bold text-white"><BarChart3 className="h-5 w-5 text-amber-300" /> Congestion today</h3>
              <span className="rounded-full bg-amber-400/10 px-2.5 py-1 text-[11px] font-bold text-amber-300">PEAK 6 PM</span>
            </div>
            <div className="mt-5 flex h-44 items-end gap-1.5">
              {trafficByHour.map((d) => {
                const hot = d.v >= 80;
                return (
                  <div key={d.h} className="group flex flex-1 flex-col items-center gap-1.5">
                    <div className="flex w-full flex-1 items-end">
                      <div className={`w-full rounded-t-md transition-all ${hot ? "bg-gradient-to-t from-red-600 to-amber-400" : d.v > 50 ? "bg-gradient-to-t from-amber-600/80 to-amber-300" : "bg-gradient-to-t from-emerald-700 to-emerald-400"}`} style={{ height: `${(d.v / maxTraffic) * 100}%` }} title={`${d.h}: ${d.v}%`} />
                    </div>
                    <span className="font-mono2 text-[9px] text-slate-500">{d.h}</span>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 rounded-xl bg-white/[0.04] p-3 text-xs leading-relaxed text-slate-400">Adaptive signals cut average commute to <span className="font-bold text-white">22 min</span> — 9 min below national average.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
