import { useEffect, useRef, useState } from "react";
import { Bot, X, Send, Siren } from "lucide-react";

const faqs = [
  { q: "Next metro to Central Hub?", a: "M1 Azure arrives in 2 min from platform 1, then every 3 min. M3 Violet in 4 min. Both accept CityPass tap." },
  { q: "Nearest ER with shortest wait?", a: "Tech Park Smart Clinic — 5 min wait, 1.2 km away. For trauma, Novapolis General (12 min wait) is Level-1 certified." },
  { q: "How do I pay property tax?", a: "CityPass → Services → Tax & Finance. You can pay by card, bank or wallet. Receipt is instant and e-signed." },
  { q: "Is the city safe right now?", a: "Yes — threat level is LOW with no citywide advisories. 42 response stations active, avg. response 6:20." },
];

export default function Assistant() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<{ from: "bot" | "me"; text: string }[]>([
    { from: "bot", text: "Hi! I'm Nova, your city assistant. Ask me about transit, hospitals, services or safety — or tap a suggestion below." },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, open, typing]);

  const reply = (text: string) => {
    const t = text.toLowerCase();
    if (t.includes("metro") || t.includes("bus") || t.includes("transit") || t.includes("train") || t.includes("bike")) return "Live now: M1 on-time (every 3 min), M2 slight 3-min delay, M3 on-time. Buses B07/B12 under 6 min. 1,240 CityCycle bikes free. Say 'plan' and I'll route you.";
    if (t.includes("hospital") || t.includes("er") || t.includes("doctor") || t.includes("health") || t.includes("ambulance")) return "6 major hospitals nearby. Shortest ER wait: Tech Park Smart Clinic (5 min). Ambulance: 913. Want me to book a telehealth slot?";
    if (t.includes("school") || t.includes("university") || t.includes("admission") || t.includes("library")) return "2027 admissions are open! 148 schools + 9 universities. Central Grand Library is open till 11PM today with free seats.";
    if (t.includes("tax") || t.includes("bill") || t.includes("permit") || t.includes("water") || t.includes("power") || t.includes("waste")) return "You can raise that in Services — avg. fix time 7.4h. Share your district and issue, and I'll pre-fill the ticket for you.";
    if (t.includes("emergency") || t.includes("sos") || t.includes("police") || t.includes("fire") || t.includes("safe")) return "Emergency numbers: Police 911 · Fire 912 · Ambulance 913 · Disaster 914. Threat level LOW. For immediate danger use the red SOS panel in the Emergency section.";
    if (t.includes("visit") || t.includes("place") || t.includes("park") || t.includes("museum") || t.includes("tour")) return "Must-see: Sky Needle Observatory (4.9★), Meridian Grand Park, Museum of Light. Harborfront sunset decks are perfect around 6:30PM today.";
    if (t.includes("hi") || t.includes("hello") || t.includes("hey")) return "Hello! How can I help you explore Novapolis today?";
    if (t.includes("thank")) return "You're welcome! I'm here 24/7 — stay safe and enjoy the city.";
    return "I can help with transit times, hospitals, schools, service requests, emergencies and places to visit. Try asking 'next metro?' or 'nearest hospital?'.";
  };

  const send = (text: string) => {
    const clean = text.trim();
    if (!clean) return;
    setMsgs((m) => [...m, { from: "me", text: clean }]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [...m, { from: "bot", text: reply(clean) }]);
    }, 900);
  };

  return (
    <>
      {/* floating buttons */}
      <div className="fixed bottom-5 right-5 z-[70] flex flex-col items-end gap-2.5">
        <a href="#emergency" className="flex items-center gap-1.5 rounded-full bg-red-500 px-4 py-2.5 text-xs font-bold text-white shadow-xl shadow-red-500/40 transition hover:bg-red-400">
          <Siren className="h-4 w-4" /> SOS
        </a>
        <button onClick={() => setOpen(!open)} className="group flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-sky-500 py-2.5 pl-3 pr-4 text-sm font-bold text-[#050914] shadow-xl shadow-cyan-500/40 transition hover:brightness-110">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#050914]/15">{open ? <X className="h-4 w-4" /> : <Bot className="h-5 w-5" />}</span>
          {open ? "Close" : "Ask Nova"}
          {!open && <span className="absolute -right-0.5 -top-0.5 flex h-3 w-3"><span className="absolute h-full w-full animate-ping rounded-full bg-emerald-400" /><span className="relative h-3 w-3 rounded-full border-2 border-[#050914] bg-emerald-400" /></span>}
        </button>
      </div>

      {open && (
        <div className="glass-strong fixed bottom-32 right-5 z-[70] flex h-[480px] w-[calc(100vw-40px)] max-w-sm flex-col overflow-hidden rounded-3xl shadow-2xl">
          <div className="flex items-center gap-3 bg-gradient-to-r from-cyan-500/25 to-violet-500/15 px-5 py-4">
            <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-sky-600"><Bot className="h-5 w-5 text-white" /></span>
            <div>
              <p className="font-display text-[15px] font-bold text-white">Nova · City AI</p>
              <p className="flex items-center gap-1 text-[11px] text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Online · replies instantly</p>
            </div>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <div key={i} className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[13px] leading-relaxed ${m.from === "bot" ? "rounded-tl-md bg-white/[0.07] text-slate-200" : "ml-auto rounded-tr-md bg-gradient-to-r from-cyan-400 to-sky-500 text-[#050914] font-medium"}`}>
                {m.text}
              </div>
            ))}
            {typing && (
              <div className="flex w-16 items-center justify-center gap-1 rounded-2xl rounded-tl-md bg-white/[0.07] px-3 py-3">
                {[0, 1, 2].map((d) => <span key={d} className="animate-bounce h-1.5 w-1.5 rounded-full bg-cyan-300" style={{ animationDelay: `${d * 150}ms` }} />)}
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar px-4 pb-2">
            {faqs.map((f) => (
              <button key={f.q} onClick={() => send(f.q)} className="shrink-0 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] font-medium text-slate-300 transition hover:border-cyan-400/40 hover:text-cyan-200">{f.q}</button>
            ))}
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex items-center gap-2 border-t border-white/10 p-3">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about metro, hospitals, services…" className="flex-1 rounded-xl bg-white/5 px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-400/50" />
            <button className="rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 p-2.5 text-[#050914]"><Send className="h-4 w-4" /></button>
          </form>
        </div>
      )}
    </>
  );
}
