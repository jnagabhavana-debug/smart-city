import { useMemo, useState } from "react";
import { HeartPulse, Search, Star, Clock, BedDouble, Phone, MapPin, BadgeCheck, Stethoscope, Siren, Video } from "lucide-react";
import { hospitals } from "../data/cityData";

export default function Healthcare() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("All");

  const list = useMemo(() => {
    return hospitals.filter((h) => {
      const matchQ = (h.name + h.district + h.specialties.join(" ")).toLowerCase().includes(q.toLowerCase());
      const matchF = filter === "All" || (filter === "24/7" ? h.open24 : filter === "Trauma" ? h.trauma : h.type.toLowerCase().includes(filter.toLowerCase()));
      return matchQ && matchF;
    });
  }, [q, filter]);

  return (
    <section id="health" className="relative py-20">
      <div className="pointer-events-none absolute right-0 top-20 h-80 w-80 rounded-full bg-rose-500/10 blur-3xl" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono2 text-xs tracking-[0.25em] text-rose-300">03 · HEALTH & CARE</p>
            <h2 className="font-display mt-2 text-3xl font-bold text-white sm:text-4xl">Hospitals & emergency care</h2>
            <p className="mt-2 max-w-xl text-slate-400">Live ER wait times, bed availability and specialist finder across 26 hospitals & 140 clinics.</p>
          </div>
          <div className="flex gap-2">
            <a href="#emergency" className="flex items-center gap-2 rounded-2xl bg-red-500 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-red-500/30 transition hover:bg-red-400">
              <Siren className="h-4 w-4" /> Ambulance · 913
            </a>
            <button className="glass flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold text-white transition hover:border-cyan-400/40">
              <Video className="h-4 w-4 text-cyan-300" /> Telehealth
            </button>
          </div>
        </div>

        {/* KPI strip */}
        <div className="reveal mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { icon: Clock, k: "Avg. ER wait", v: "11 min", s: "↓ 34% this year", c: "text-emerald-300" },
            { icon: BedDouble, k: "Beds available", v: "192", s: "of 2,060 citywide", c: "text-cyan-300" },
            { icon: Stethoscope, k: "Doctors on duty", v: "1,480", s: "across 26 facilities", c: "text-violet-300" },
            { icon: BadgeCheck, k: "AI triage accuracy", v: "97.2%", s: "certified by HealthBoard", c: "text-lime-300" },
          ].map((x) => (
            <div key={x.k} className="glass flex items-center gap-3 rounded-2xl p-4">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/[0.06]"><x.icon className={`h-5 w-5 ${x.c}`} /></span>
              <div>
                <p className="text-[11px] uppercase tracking-wider text-slate-500">{x.k}</p>
                <p className="font-display text-xl font-bold text-white">{x.v}</p>
                <p className="text-[11px] text-slate-400">{x.s}</p>
              </div>
            </div>
          ))}
        </div>

        {/* search + filters */}
        <div className="reveal mt-6 flex flex-col gap-3 md:flex-row md:items-center">
          <div className="glass flex flex-1 items-center gap-2 rounded-2xl px-4 py-3">
            <Search className="h-4 w-4 text-slate-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search hospitals, specialties, districts…" className="w-full bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none" />
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {["All", "24/7", "Trauma", "Public", "Private", "Specialist", "Clinic"].map((f) => (
              <button key={f} onClick={() => setFilter(f)} className={`shrink-0 rounded-xl px-4 py-2.5 text-[13px] font-bold transition ${filter === f ? "bg-rose-400 text-[#050914]" : "glass text-slate-300 hover:text-white"}`}>{f}</button>
            ))}
          </div>
        </div>

        {/* cards */}
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {list.map((h, i) => (
            <div key={h.id} className={`reveal ${i % 3 === 1 ? "reveal-delay-1" : i % 3 === 2 ? "reveal-delay-2" : ""} glass card-glow rounded-3xl p-5`}>
              <div className="flex items-start justify-between gap-2">
                <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${h.open24 ? "bg-emerald-400/15 text-emerald-300" : "bg-amber-400/15 text-amber-300"}`}>{h.open24 ? "● OPEN 24/7" : "○ 8AM – 10PM"}</span>
                <span className="flex items-center gap-1 text-sm font-bold text-amber-300"><Star className="h-3.5 w-3.5 fill-amber-300" /> {h.rating}</span>
              </div>
              <h3 className="font-display mt-3 text-[17px] font-bold leading-snug text-white">{h.name}</h3>
              <p className="mt-0.5 text-xs font-medium text-cyan-300">{h.type}</p>
              <p className="mt-1 flex items-center gap-1 text-xs text-slate-400"><MapPin className="h-3 w-3" /> {h.district} District</p>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {h.specialties.map((s) => (
                  <span key={s} className="rounded-lg bg-white/[0.06] px-2 py-1 text-[11px] font-medium text-slate-300">{s}</span>
                ))}
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 rounded-2xl bg-white/[0.03] p-3 ring-1 ring-white/5">
                <div className="text-center">
                  <p className="font-display text-lg font-bold text-white">{h.erWait}<span className="text-[11px] font-medium text-slate-400">m</span></p>
                  <p className="text-[10px] uppercase tracking-wider text-slate-500">ER wait</p>
                </div>
                <div className="border-x border-white/10 text-center">
                  <p className="font-display text-lg font-bold text-emerald-300">{h.availableBeds}</p>
                  <p className="text-[10px] uppercase tracking-wider text-slate-500">Beds free</p>
                </div>
                <div className="text-center">
                  <p className="font-display text-lg font-bold text-white">{Math.round((h.availableBeds / h.beds) * 100)}<span className="text-[11px] font-medium text-slate-400">%</span></p>
                  <p className="text-[10px] uppercase tracking-wider text-slate-500">Capacity</p>
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <a href={`tel:${h.phone}`} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-white/10 py-2.5 text-[13px] font-bold text-white transition hover:bg-white/15"><Phone className="h-3.5 w-3.5" /> {h.phone}</a>
                <button className="flex-1 rounded-xl bg-gradient-to-r from-rose-400 to-red-500 py-2.5 text-[13px] font-bold text-white transition hover:brightness-110">Book visit</button>
              </div>
            </div>
          ))}
        </div>
        {list.length === 0 && (
          <div className="glass mt-6 rounded-3xl p-10 text-center">
            <HeartPulse className="mx-auto h-10 w-10 text-slate-600" />
            <p className="mt-3 font-semibold text-white">No facilities match your search</p>
            <p className="text-sm text-slate-400">Try a different specialty or district — or call 913 for guidance.</p>
          </div>
        )}
      </div>
    </section>
  );
}
