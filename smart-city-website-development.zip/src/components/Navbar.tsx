import { useEffect, useState } from "react";
import { Building2, Menu, X, Search, Bell, ChevronDown } from "lucide-react";

const links = [
  { label: "City Stats", href: "#stats" },
  { label: "Transport", href: "#transport" },
  { label: "Hospitals", href: "#health" },
  { label: "Education", href: "#education" },
  { label: "Services", href: "#services" },
  { label: "Emergency", href: "#emergency" },
  { label: "Explore", href: "#explore" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [query, setQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? "glass-strong shadow-[0_10px_40px_-10px_rgba(34,211,238,0.3)]" : "bg-transparent"}`}>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
        <a href="#top" className="group flex items-center gap-2.5">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-violet-600 shadow-lg shadow-cyan-500/30">
            <Building2 className="h-5 w-5 text-white" />
            <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full border-2 border-[#050914] bg-emerald-400" />
          </span>
          <span className="leading-tight">
            <span className="font-display block text-[17px] font-700 font-bold tracking-tight text-white">
              NOVA<span className="text-cyan-400">POLIS</span>
            </span>
            <span className="block text-[10px] font-medium uppercase tracking-[0.22em] text-slate-400">Smart City Portal</span>
          </span>
        </a>

        <div className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="rounded-lg px-3 py-2 text-[13.5px] font-medium text-slate-300 transition hover:bg-white/5 hover:text-cyan-300">
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className={`hidden items-center overflow-hidden transition-all duration-300 md:flex ${showSearch ? "w-56 opacity-100" : "w-0 opacity-0"}`}>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search services, places…"
              className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
          <button onClick={() => setShowSearch(!showSearch)} className="rounded-lg p-2 text-slate-300 transition hover:bg-white/10 hover:text-cyan-300" aria-label="Search">
            <Search className="h-5 w-5" />
          </button>
          <button className="relative hidden rounded-lg p-2 text-slate-300 transition hover:bg-white/10 hover:text-cyan-300 sm:block" aria-label="Notifications">
            <Bell className="h-5 w-5" />
            <span className="absolute right-1.5 top-1.5 flex h-2 w-2">
              <span className="absolute h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
              <span className="relative h-2 w-2 rounded-full bg-red-400" />
            </span>
          </button>
          <a href="#services" className="hidden items-center gap-1 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 px-4 py-2 text-sm font-semibold text-[#050914] shadow-lg shadow-cyan-500/25 transition hover:brightness-110 md:flex">
            CityPass Login <ChevronDown className="h-4 w-4" />
          </a>
          <button onClick={() => setOpen(!open)} className="rounded-lg p-2 text-slate-200 hover:bg-white/10 lg:hidden" aria-label="Menu">
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>
      {query && showSearch && (
        <div className="absolute right-4 top-full z-50 mt-1 w-72 rounded-xl border border-white/10 bg-[#0a1230]/95 p-2 shadow-2xl backdrop-blur-xl md:right-24">
          {["Metro M1 — Azure Line live status", "Novapolis General Hospital — ER 12 min", "Pay property tax online", "Book Central Grand Library seat", "Report pothole — Civic Center"].filter(s => s.toLowerCase().includes(query.toLowerCase())).map((s, i) => (
            <button key={i} className="block w-full rounded-lg px-3 py-2 text-left text-sm text-slate-300 hover:bg-white/5 hover:text-cyan-300">{s}</button>
          ))}
          {["Metro M1 — Azure Line live status", "Novapolis General Hospital — ER 12 min", "Pay property tax online", "Book Central Grand Library seat", "Report pothole — Civic Center"].filter(s => s.toLowerCase().includes(query.toLowerCase())).length === 0 && (
            <p className="px-3 py-2 text-sm text-slate-500">No results for “{query}”</p>
          )}
        </div>
      )}
      {open && (
        <div className="glass-strong border-t border-white/10 px-4 pb-5 pt-2 lg:hidden">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="block rounded-lg px-3 py-2.5 text-[15px] font-medium text-slate-200 hover:bg-white/5 hover:text-cyan-300">
              {l.label}
            </a>
          ))}
          <a href="#services" onClick={() => setOpen(false)} className="mt-2 block rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 px-4 py-2.5 text-center text-sm font-semibold text-[#050914]">
            CityPass Login
          </a>
        </div>
      )}
    </header>
  );
}
