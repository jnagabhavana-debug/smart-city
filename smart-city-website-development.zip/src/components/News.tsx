import { Newspaper, ArrowUpRight, CalendarDays } from "lucide-react";
import { news, cityImages } from "../data/cityData";

export default function News() {
  return (
    <section className="relative py-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal flex items-end justify-between">
          <div>
            <p className="font-mono2 text-xs tracking-[0.25em] text-amber-300">08 · CITY PULSE</p>
            <h2 className="font-display mt-2 text-3xl font-bold text-white">News & upcoming events</h2>
          </div>
          <button className="hidden items-center gap-1 text-sm font-bold text-cyan-300 hover:text-cyan-200 sm:flex">All stories <ArrowUpRight className="h-4 w-4" /></button>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="reveal relative overflow-hidden rounded-3xl border border-white/10 md:col-span-2 lg:col-span-1 lg:row-span-1">
            <img src={cityImages.park} alt="Festival" className="h-52 w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050914] via-[#050914]/40 to-transparent" />
            <div className="absolute bottom-0 p-5">
              <span className="rounded-full bg-lime-300 px-2.5 py-1 text-[10px] font-bold text-[#050914]">FEATURED EVENT</span>
              <p className="font-display mt-2 text-lg font-bold leading-snug text-white">Festival of Lights · Dec 12–15</p>
              <p className="text-xs text-slate-300">Drone sky-show over Harborfront · 500 drones</p>
            </div>
          </div>
          {news.map((n, i) => (
            <article key={n.id} className={`reveal ${i === 1 ? "reveal-delay-1" : i === 2 ? "reveal-delay-2" : i === 3 ? "reveal-delay-3" : ""} glass card-glow group cursor-pointer rounded-3xl p-5`}>
              <div className="flex items-center justify-between">
                <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-cyan-200">{n.tag}</span>
                <Newspaper className="h-4 w-4 text-slate-500 group-hover:text-cyan-300" />
              </div>
              <h3 className="font-display mt-3 text-[15px] font-bold leading-snug text-white group-hover:text-cyan-200">{n.title}</h3>
              <div className="mt-4 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1"><CalendarDays className="h-3 w-3" /> {n.date}</span>
                <span>{n.read}</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
