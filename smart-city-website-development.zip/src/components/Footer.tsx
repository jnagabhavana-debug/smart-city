import { useState } from "react";
import { Building2, Send, CheckCircle2, Globe, AtSign, Rss, Share2, MapPin, Phone, Mail, ArrowUp } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  return (
    <footer className="relative border-t border-white/10 bg-[#03061a]">
      {/* CTA band */}
      <div className="mx-auto max-w-7xl px-4 pt-12 sm:px-6">
        <div className="reveal relative overflow-hidden rounded-3xl border border-cyan-400/20 bg-gradient-to-r from-[#0a1a3a] via-[#0c2a4a] to-[#131a4a] p-8 md:p-10">
          <div className="bg-grid absolute inset-0 opacity-40" />
          <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-cyan-400/20 blur-3xl" />
          <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <p className="font-mono2 text-xs tracking-[0.25em] text-cyan-300">GET THE APP · 4.9 ★ · 2M+ DOWNLOADS</p>
              <h3 className="font-display mt-2 text-2xl font-bold text-white sm:text-3xl">Your city in your pocket.</h3>
              <p className="mt-1 text-slate-300">Transit, bills, SOS, appointments & alerts — one secure CityPass.</p>
            </div>
            <div className="flex gap-3">
              <button className="rounded-2xl bg-white px-6 py-3 text-sm font-bold text-[#050914] transition hover:brightness-95">⬢ App Store</button>
              <button className="rounded-2xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-bold text-white backdrop-blur transition hover:bg-white/10">▶ Google Play</button>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.3fr_1fr_1fr_1.2fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-violet-600"><Building2 className="h-5 w-5 text-white" /></span>
            <span className="font-display text-lg font-bold text-white">NOVA<span className="text-cyan-400">POLIS</span></span>
          </div>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-slate-400">The official smart-city portal of Novapolis — transparent, inclusive and open 24/7 for every resident and visitor.</p>
          <div className="mt-4 space-y-2 text-sm text-slate-400">
            <p className="flex items-center gap-2"><MapPin className="h-4 w-4 text-cyan-300" /> 1 Civic Plaza, Central Hub, Novapolis</p>
            <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-cyan-300" /> Citizen helpline: 311 (24/7)</p>
            <p className="flex items-center gap-2"><Mail className="h-4 w-4 text-cyan-300" /> hello@novapolis.city</p>
          </div>
          <div className="mt-4 flex gap-2">
            {[Globe, AtSign, Rss, Share2].map((Icon, i) => (
              <button key={i} className="rounded-xl border border-white/10 bg-white/5 p-2.5 text-slate-300 transition hover:border-cyan-400/50 hover:text-cyan-300"><Icon className="h-4 w-4" /></button>
            ))}
          </div>
        </div>
        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">City services</p>
          <ul className="mt-3 space-y-2 text-sm text-slate-400">
            {["Transportation & CityPass", "Hospitals & telehealth", "Schools & admissions", "Water, power & waste", "Permits & taxes", "Housing assistance"].map((l) => (
              <li key={l}><a href="#services" className="transition hover:text-cyan-300">{l}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">Quick links</p>
          <ul className="mt-3 space-y-2 text-sm text-slate-400">
            {["City statistics dashboard", "Emergency preparedness", "District guide & map", "Jobs & tenders", "Open data portal", "Mayor's office"].map((l) => (
              <li key={l}><a href="#top" className="transition hover:text-cyan-300">{l}</a></li>
            ))}
          </ul>
        </div>
        <div>
          <p className="font-display text-sm font-bold uppercase tracking-wider text-white">City newsletter</p>
          <p className="mt-3 text-sm text-slate-400">Weekly digest: transit changes, events & civic alerts. Join 480K readers.</p>
          {!done ? (
            <form onSubmit={(e) => { e.preventDefault(); if (email) setDone(true); }} className="mt-3 flex gap-2">
              <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required placeholder="you@email.com" className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none" />
              <button className="flex items-center gap-1 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 px-4 py-2.5 text-sm font-bold text-[#050914]"><Send className="h-4 w-4" /></button>
            </form>
          ) : (
            <p className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200"><CheckCircle2 className="h-4 w-4" /> Subscribed — welcome aboard!</p>
          )}
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            {[["99.98%", "portal uptime"], ["7.4h", "avg. fix time"], ["4.9★", "citizen rating"]].map((s) => (
              <div key={s[1]} className="rounded-xl bg-white/[0.04] p-2.5 ring-1 ring-white/10">
                <p className="font-display text-sm font-bold text-white">{s[0]}</p>
                <p className="text-[10px] text-slate-500">{s[1]}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-xs text-slate-500 sm:px-6">
          <p>© 2026 Novapolis Municipal Corporation · All systems monitored · Open data CC-BY</p>
          <div className="flex items-center gap-4">
            <a href="#top" className="hover:text-cyan-300">Privacy</a>
            <a href="#top" className="hover:text-cyan-300">Accessibility</a>
            <a href="#top" className="hover:text-cyan-300">Terms</a>
            <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="flex items-center gap-1 rounded-lg bg-white/10 px-3 py-1.5 font-bold text-white transition hover:bg-cyan-400 hover:text-[#050914]"><ArrowUp className="h-3.5 w-3.5" /> Top</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
