import { useState } from "react";
import { MapPin, Star, Clock, Landmark, Palette, TreePine, Building2, ShoppingBag, Church, Search, Wind, TrainFront, Users } from "lucide-react";
import { places, districts } from "../data/cityData";

const catIcons: Record<string, any> = { Landmark, Culture: Palette, Nature: TreePine, Government: Building2, Shopping: ShoppingBag, Worship: Church };
const cats = ["All", "Landmark", "Culture", "Nature", "Government", "Shopping", "Worship"];

export default function Locations() {
  const [cat, setCat] = useState("All");
  const [q, setQ] = useState("");
  const [district, setDistrict] = useState(districts[3]);

  const filtered = places.filter((p) => (cat === "All" || p.category === cat) && (p.name + p.district + p.desc).toLowerCase().includes(q.toLowerCase()));

  return (
    <section id="explore" className="relative py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal">
          <p className="font-mono2 text-xs tracking-[0.25em] text-cyan-300">07 · EXPLORE</p>
          <h2 className="font-display mt-2 text-3xl font-bold text-white sm:text-4xl">Important places & district guide</h2>
          <p className="mt-2 max-w-xl text-slate-400">Tap a district on the smart map to inspect it — or browse 200+ curated landmarks, parks and civic spots.</p>
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[420px_1fr]">
          {/* Smart map */}
          <div className="reveal glass relative overflow-hidden rounded-3xl p-5">
            <div className="flex items-center justify-between">
              <p className="font-mono2 text-[11px] tracking-[0.2em] text-slate-400">NOVAPOLIS · SMART MAP</p>
              <span className="flex items-center gap-1.5 rounded-full bg-emerald-400/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300"><span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" /> LIVE</span>
            </div>

            {/* stylized map */}
            <div className="relative mt-4 h-[420px] overflow-hidden rounded-2xl border border-white/10 bg-[#070d24]">
              <div className="bg-grid absolute inset-0 opacity-50" />
              {/* river */}
              <svg className="absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <path d="M 0 55 C 25 50, 35 62, 55 58 S 80 44, 100 52" stroke="#0ea5e9" strokeOpacity="0.35" strokeWidth="3.5" fill="none" strokeLinecap="round" />
                <path d="M 20 0 C 30 30, 28 60, 46 100" stroke="#22d3ee" strokeOpacity="0.12" strokeWidth="6" fill="none" />
                {/* metro lines */}
                <path d="M 52 12 L 50 46 L 58 74" stroke="#22d3ee" strokeOpacity="0.5" strokeWidth="0.8" fill="none" strokeDasharray="2 1.5" />
                <path d="M 26 62 L 50 46 L 78 66" stroke="#a78bfa" strokeOpacity="0.5" strokeWidth="0.8" fill="none" strokeDasharray="2 1.5" />
                <path d="M 30 30 L 50 46 L 74 26" stroke="#4ade80" strokeOpacity="0.5" strokeWidth="0.8" fill="none" strokeDasharray="2 1.5" />
              </svg>
              {districts.map((d) => (
                <button
                  key={d.id}
                  onClick={() => setDistrict(d)}
                  className="group absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${d.x}%`, top: `${d.y}%` }}
                >
                  <span className={`relative flex h-4 w-4 items-center justify-center rounded-full transition ${district.id === d.id ? "scale-125 bg-cyan-300 shadow-[0_0_18px_rgba(34,211,238,0.9)]" : "bg-cyan-500/70 hover:bg-cyan-300"}`}>
                    {district.id === d.id && <span className="absolute inset-0 animate-ping rounded-full bg-cyan-300/50" />}
                  </span>
                  <span className={`absolute left-1/2 top-5 -translate-x-1/2 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[9px] font-bold ${district.id === d.id ? "bg-cyan-300 text-[#050914]" : "bg-black/60 text-slate-300 group-hover:text-white"}`}>{d.name}</span>
                </button>
              ))}
              {/* compass */}
              <div className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-black/50 font-mono2 text-[10px] font-bold text-cyan-300">N↑</div>
            </div>

            {/* district card */}
            <div className="mt-4 rounded-2xl border border-cyan-400/25 bg-cyan-400/[0.06] p-4">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg font-bold text-white">{district.name}</h3>
                <span className="flex items-center gap-1 text-xs font-bold text-slate-300"><Users className="h-3.5 w-3.5 text-cyan-300" /> {district.pop}</span>
              </div>
              <p className="mt-1 text-[13px] text-slate-300">{district.desc}</p>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <span className="flex items-center gap-1.5 rounded-lg bg-black/30 px-2.5 py-2 text-slate-300"><Wind className="h-3.5 w-3.5 text-emerald-300" /> AQI {district.aqi} · Good</span>
                <span className="flex items-center gap-1.5 rounded-lg bg-black/30 px-2.5 py-2 text-slate-300"><TrainFront className="h-3.5 w-3.5 text-violet-300" /> {district.transit}</span>
              </div>
            </div>
          </div>

          {/* directory */}
          <div>
            <div className="reveal flex flex-col gap-3 sm:flex-row">
              <div className="glass flex flex-1 items-center gap-2 rounded-2xl px-4 py-3">
                <Search className="h-4 w-4 text-slate-400" />
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search landmarks, parks, museums…" className="w-full bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none" />
              </div>
            </div>
            <div className="reveal mt-3 flex gap-2 overflow-x-auto no-scrollbar pb-1">
              {cats.map((c) => (
                <button key={c} onClick={() => setCat(c)} className={`shrink-0 rounded-xl px-4 py-2 text-[13px] font-bold transition ${cat === c ? "bg-gradient-to-r from-cyan-400 to-sky-500 text-[#050914]" : "glass text-slate-300 hover:text-white"}`}>{c}</button>
              ))}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {filtered.map((p, i) => {
                const Icon = catIcons[p.category];
                return (
                  <div key={p.id} className={`reveal ${i % 2 === 1 ? "reveal-delay-1" : ""} glass card-glow group rounded-2xl p-5`}>
                    <div className="flex items-start justify-between">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500/25 to-violet-500/20 ring-1 ring-white/10"><Icon className="h-5 w-5 text-cyan-300" /></span>
                      <span className="flex items-center gap-1 text-sm font-bold text-amber-300"><Star className="h-3.5 w-3.5 fill-amber-300" /> {p.rating}</span>
                    </div>
                    <h3 className="font-display mt-3 text-[15.5px] font-bold leading-snug text-white group-hover:text-cyan-200">{p.name}</h3>
                    <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-slate-400">{p.desc}</p>
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px]">
                      <span className="rounded-md bg-cyan-400/15 px-2 py-1 font-bold text-cyan-200">{p.category}</span>
                      <span className="flex items-center gap-1 text-slate-400"><MapPin className="h-3 w-3" /> {p.district}</span>
                      <span className="flex items-center gap-1 text-slate-400"><Clock className="h-3 w-3" /> {p.open}</span>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <button className="flex-1 rounded-xl bg-white/10 py-2 text-xs font-bold text-white transition hover:bg-cyan-400 hover:text-[#050914]">Directions</button>
                      <button className="flex-1 rounded-xl border border-white/10 py-2 text-xs font-bold text-slate-300 transition hover:border-cyan-400/40 hover:text-cyan-200">Save ♥</button>
                    </div>
                  </div>
                );
              })}
            </div>
            {filtered.length === 0 && <p className="glass mt-4 rounded-2xl p-6 text-center text-sm text-slate-400">No places found — try another search.</p>}
          </div>
        </div>
      </div>
    </section>
  );
}
