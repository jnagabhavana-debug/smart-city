import { useState } from "react";
import { Droplets, Zap, Recycle, FileCheck, TrafficCone, Wallet, Home, Leaf, X, CheckCircle2, ClipboardList, ChevronRight } from "lucide-react";
import { publicServices } from "../data/cityData";

const iconMap: Record<string, any> = {
  droplets: Droplets, zap: Zap, recycle: Recycle, file: FileCheck, road: TrafficCone, wallet: Wallet, home: Home, leaf: Leaf,
};

export default function Services() {
  const [active, setActive] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", district: "Central Hub", detail: "" });
  const [ticket, setTicket] = useState<string | null>(null);
  const [track, setTrack] = useState("");
  const [trackResult, setTrackResult] = useState<string | null>(null);

  const svc = publicServices.find((s) => s.id === active);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = "NVP-" + Math.floor(100000 + Math.random() * 900000);
    setTicket(id);
  };

  const doTrack = () => {
    if (!track.trim()) return;
    setTrackResult(`Ticket ${track.toUpperCase()} · In progress — crew assigned, ETA 6 hrs · Civic Center depot`);
  };

  return (
    <section id="services" className="relative py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal">
          <p className="font-mono2 text-xs tracking-[0.25em] text-emerald-300">05 · CITIZEN SERVICES</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">Public services, one click away</h2>
              <p className="mt-2 max-w-xl text-slate-400">Raise a request in 30 seconds. Average resolution time: <span className="font-bold text-emerald-300">7.4 hours</span> — tracked live to your phone.</p>
            </div>
            {/* tracker */}
            <div className="glass flex items-center gap-2 rounded-2xl p-2 pl-4">
              <ClipboardList className="h-4 w-4 text-emerald-300" />
              <input value={track} onChange={(e) => setTrack(e.target.value)} placeholder="Track ticket e.g. NVP-482910" className="w-52 bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none" />
              <button onClick={doTrack} className="rounded-xl bg-emerald-400 px-4 py-2 text-sm font-bold text-[#050914] transition hover:brightness-110">Track</button>
            </div>
          </div>
          {trackResult && (
            <div className="mt-3 flex items-center gap-2 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200">
              <CheckCircle2 className="h-4 w-4" /> {trackResult}
            </div>
          )}
        </div>

        <div className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {publicServices.map((s, i) => {
            const Icon = iconMap[s.icon];
            return (
              <button key={s.id} onClick={() => { setActive(s.id); setTicket(null); }} className={`reveal ${i % 4 === 1 ? "reveal-delay-1" : i % 4 === 2 ? "reveal-delay-2" : i % 4 === 3 ? "reveal-delay-3" : ""} glass card-glow group rounded-3xl p-5 text-left`}>
                <div className="flex items-start justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-400/25 to-cyan-500/20 ring-1 ring-white/10 transition group-hover:scale-105"><Icon className="h-6 w-6 text-emerald-300" /></span>
                  <span className={`rounded-full px-2 py-1 text-[10px] font-bold ${s.statusTone === "green" ? "bg-emerald-400/15 text-emerald-300" : "bg-amber-400/15 text-amber-300"}`}>{s.status}</span>
                </div>
                <p className="font-display mt-3 text-[16px] font-bold text-white">{s.title}</p>
                <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-slate-400">{s.desc}</p>
                <p className="mt-3 flex items-center justify-between text-xs">
                  <span className="font-mono2 text-slate-500">{s.requests24h} today</span>
                  <span className="flex items-center gap-0.5 font-bold text-emerald-300">Request <ChevronRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" /></span>
                </p>
              </button>
            );
          })}
        </div>

        {/* utility status */}
        <div className="reveal mt-5 grid gap-3 md:grid-cols-3">
          {[
            { k: "Water quality", v: "Excellent · pH 7.2", pct: 96, c: "from-sky-400 to-cyan-300" },
            { k: "Power grid load", v: "61% · stable", pct: 61, c: "from-amber-400 to-lime-300" },
            { k: "Waste recycled", v: "74% this month", pct: 74, c: "from-emerald-400 to-teal-300" },
          ].map((u) => (
            <div key={u.k} className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between text-sm"><span className="font-semibold text-slate-300">{u.k}</span><span className="font-mono2 font-bold text-white">{u.v}</span></div>
              <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-white/10"><div className={`h-full rounded-full bg-gradient-to-r ${u.c}`} style={{ width: `${u.pct}%` }} /></div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {active && svc && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setActive(null)}>
          <div className="glass-strong w-full max-w-md overflow-hidden rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between bg-gradient-to-r from-emerald-500/20 to-cyan-500/10 px-6 py-4">
              <p className="font-display text-lg font-bold text-white">{svc.title}</p>
              <button onClick={() => setActive(null)} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/10 hover:text-white"><X className="h-5 w-5" /></button>
            </div>
            {!ticket ? (
              <form onSubmit={submit} className="space-y-3 p-6">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Full name</label>
                  <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Amara Chen" className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400/60 focus:outline-none" />
                </div>
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">District</label>
                  <select value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="mt-1.5 w-full rounded-xl border border-white/10 bg-[#0a1230] px-4 py-2.5 text-sm text-white focus:border-emerald-400/60 focus:outline-none">
                    {["Central Hub", "Meridian", "Harborfront", "Old Town", "Tech Park", "Lakeside", "Northgate", "Southport"].map((d) => <option key={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Describe the issue</label>
                  <textarea required value={form.detail} onChange={(e) => setForm({ ...form, detail: e.target.value })} rows={3} placeholder="e.g. Streetlight out on Palm Ave near bus stop…" className="mt-1.5 w-full rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400/60 focus:outline-none" />
                </div>
                <button className="w-full rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 py-3 text-sm font-bold text-[#050914] transition hover:brightness-110">Submit request</button>
                <p className="text-center text-[11px] text-slate-500">Avg. response 22 min · SMS + app updates included</p>
              </form>
            ) : (
              <div className="p-8 text-center">
                <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-400/15"><CheckCircle2 className="h-8 w-8 text-emerald-300" /></span>
                <h3 className="font-display mt-4 text-xl font-bold text-white">Request received!</h3>
                <p className="mt-1 text-sm text-slate-400">Ticket <span className="font-mono2 font-bold text-emerald-300">{ticket}</span> for {form.district}</p>
                <div className="mt-4 rounded-2xl bg-white/[0.05] p-4 text-left text-xs text-slate-300">
                  <p><span className="font-bold text-white">Crew:</span> Depot 4 · Team B assigned</p>
                  <p className="mt-1"><span className="font-bold text-white">ETA:</span> within 6 hours</p>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10"><div className="h-full w-1/3 rounded-full bg-emerald-400" /></div>
                </div>
                <button onClick={() => setActive(null)} className="mt-4 w-full rounded-xl bg-white/10 py-3 text-sm font-bold text-white hover:bg-white/15">Done</button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
