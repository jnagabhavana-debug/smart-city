import { useEffect, useState } from "react";
import { TrainFront, Bus, Bike, PlugZap, Clock, ArrowRight, CircleDot, Navigation, Fuel } from "lucide-react";
import { metroLines, busRoutes, bikeStations, evStations, cityImages } from "../data/cityData";

const tabs = [
  { id: "metro", label: "Metro", icon: TrainFront },
  { id: "bus", label: "Buses", icon: Bus },
  { id: "bike", label: "Bike Share", icon: Bike },
  { id: "ev", label: "EV Charging", icon: PlugZap },
];

function useCountdown(initial: number[]) {
  const [etas, setEtas] = useState(initial);
  useEffect(() => {
    const t = setInterval(() => {
      setEtas((prev) => prev.map((e) => (e <= 1 ? 12 + Math.floor(Math.random() * 8) : e - 1)));
    }, 8000);
    return () => clearInterval(t);
  }, []);
  return etas;
}

function BusBoard() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 5000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="space-y-3">
      {busRoutes.map((b, i) => {
        const live = b.eta.map((e) => Math.max(1, e - (tick % 3) + (i % 2)));
        return (
          <div key={b.id} className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition hover:border-cyan-400/30">
            <span className="flex h-12 w-14 flex-col items-center justify-center rounded-xl font-mono2 text-sm font-bold text-[#050914]" style={{ background: b.color }}>
              {b.id}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-white">{b.from} → {b.to}</p>
              <p className="text-xs text-slate-400">Occupancy: <span className={b.occupancy === "High" ? "text-red-300" : b.occupancy === "Moderate" ? "text-amber-300" : "text-emerald-300"}>{b.occupancy}</span></p>
            </div>
            <div className="flex gap-1.5">
              {live.map((e, j) => (
                <span key={j} className={`rounded-lg px-2.5 py-1.5 font-mono2 text-xs font-bold ${j === 0 ? "bg-lime-300 text-[#050914]" : "bg-white/10 text-slate-200"}`}>{e}m</span>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function Transportation() {
  const [tab, setTab] = useState("metro");
  const [line, setLine] = useState(metroLines[0]);
  const metroEtas = useCountdown([2, 5, 9]);

  return (
    <section id="transport" className="relative py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal">
          <p className="font-mono2 text-xs tracking-[0.25em] text-cyan-300">02 · MOBILITY</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">Move through the city, intelligently</h2>
              <p className="mt-2 max-w-xl text-slate-400">4 metro lines · 86 bus routes · 92 bike stations · 58 EV hubs — unified under one CityPass tap.</p>
            </div>
            <div className="glass flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm">
              <span className="animate-pulse-dot h-2 w-2 rounded-full bg-emerald-400" />
              <span className="font-semibold text-white">96.4% on-time</span>
              <span className="text-slate-400">network-wide</span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="reveal mt-7 flex gap-2 overflow-x-auto no-scrollbar">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex shrink-0 items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition ${tab === t.id ? "bg-gradient-to-r from-cyan-400 to-sky-500 text-[#050914] shadow-lg shadow-cyan-500/30" : "glass text-slate-300 hover:text-white"}`}>
              <t.icon className="h-4.5 w-4.5" /> {t.label}
            </button>
          ))}
        </div>

        <div className="mt-6 grid gap-5 lg:grid-cols-[1fr_380px]">
          {/* Main panel */}
          <div className="glass reveal overflow-hidden rounded-3xl">
            {tab === "metro" && (
              <div className="grid md:grid-cols-[280px_1fr]">
                <div className="space-y-2 border-b border-white/10 bg-white/[0.02] p-4 md:border-b-0 md:border-r">
                  {metroLines.map((l) => (
                    <button key={l.id} onClick={() => setLine(l)} className={`w-full rounded-2xl border p-3.5 text-left transition ${line.id === l.id ? "border-white/20 bg-white/[0.06]" : "border-transparent hover:bg-white/[0.04]"}`}>
                      <div className="flex items-center gap-2.5">
                        <span className="h-9 w-1.5 rounded-full" style={{ background: l.color }} />
                        <div>
                          <p className="text-sm font-bold text-white">{l.id} · {l.name}</p>
                          <p className="text-xs text-slate-400">{l.frequency}</p>
                        </div>
                      </div>
                      <span className={`mt-2 inline-block rounded-full px-2 py-0.5 text-[11px] font-bold ${l.status === "on-time" ? "bg-emerald-400/15 text-emerald-300" : l.status === "delayed" ? "bg-amber-400/15 text-amber-300" : "bg-violet-400/15 text-violet-300"}`}>{l.statusText}</span>
                    </button>
                  ))}
                  <div className="overflow-hidden rounded-2xl">
                    <img src={cityImages.metro2} alt="Metro" className="h-32 w-full object-cover" />
                  </div>
                </div>
                <div className="relative p-6">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <h3 className="font-display text-xl font-bold text-white">{line.id} — {line.name}</h3>
                    <div className="flex gap-2">
                      {metroEtas.map((e, i) => (
                        <span key={i} className="flex items-center gap-1 rounded-xl bg-white/[0.06] px-3 py-1.5 font-mono2 text-xs font-bold text-lime-300 ring-1 ring-white/10"><Clock className="h-3 w-3" /> {e} min</span>
                      ))}
                    </div>
                  </div>
                  {/* route line */}
                  <div className="relative mt-6 pl-2">
                    <div className="absolute bottom-4 left-[15px] top-4 w-1 rounded-full" style={{ background: `linear-gradient(180deg, ${line.color}, ${line.color}55)` }} />
                    <div className="space-y-4">
                      {line.stations.map((s, i) => (
                        <div key={s} className="relative flex items-center gap-4 pl-1">
                          <span className="z-10 flex h-5 w-5 items-center justify-center rounded-full border-2 bg-[#0a1230]" style={{ borderColor: line.color }}>
                            {i === 3 && <span className="h-1.5 w-1.5 rounded-full" style={{ background: line.color }} />}
                          </span>
                          <span className={`rounded-xl px-3 py-1.5 text-sm ${i === 3 ? "bg-white/10 font-bold text-white ring-1 ring-white/15" : "text-slate-300"}`}>{s} {i === 3 && <span className="ml-1 text-[10px] font-bold text-cyan-300">● YOU ARE HERE</span>}</span>
                          {i < 2 && <span className="ml-auto hidden font-mono2 text-[11px] text-slate-500 sm:block">-{(3 - i) * 2} min</span>}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-6 flex flex-wrap gap-2">
                    <button className="flex items-center gap-1.5 rounded-xl bg-white/10 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/15"><Navigation className="h-4 w-4 text-cyan-300" /> Plan journey</button>
                    <button className="flex items-center gap-1.5 rounded-xl border border-white/10 px-4 py-2.5 text-sm font-semibold text-slate-300 transition hover:border-cyan-400/40 hover:text-cyan-200">Full timetable <ArrowRight className="h-4 w-4" /></button>
                  </div>
                </div>
              </div>
            )}

            {tab === "bus" && (
              <div className="grid md:grid-cols-[1fr_300px]">
                <div className="p-6"><BusBoard /></div>
                <div className="relative min-h-64 overflow-hidden">
                  <img src={cityImages.metro1} alt="Transit" className="absolute inset-0 h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a1230] via-[#0a1230]/60 to-transparent" />
                  <div className="absolute bottom-0 p-5">
                    <p className="font-display text-lg font-bold text-white">Night Owl Network</p>
                    <p className="text-sm text-slate-300">14 routes run 24/7. Track every bus live in the Novapolis app.</p>
                  </div>
                </div>
              </div>
            )}

            {tab === "bike" && (
              <div className="grid md:grid-cols-[300px_1fr]">
                <div className="relative min-h-64 overflow-hidden">
                  <img src={cityImages.bikes} alt="Bikes" className="absolute inset-0 h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a1230] via-transparent to-transparent" />
                  <div className="absolute bottom-0 p-5">
                    <p className="font-display text-lg font-bold text-white">CityCycle</p>
                    <p className="text-sm text-slate-300">First 30 min free with CityPass.</p>
                  </div>
                </div>
                <div className="space-y-3 p-6">
                  {bikeStations.map((b) => (
                    <div key={b.name} className="flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                      <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-400/15"><Bike className="h-5 w-5 text-emerald-300" /></span>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-white">{b.name}</p>
                        <div className="mt-1.5 flex h-1.5 overflow-hidden rounded-full bg-white/10">
                          <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-lime-300" style={{ width: `${(b.bikes / (b.bikes + b.docks)) * 100}%` }} />
                        </div>
                        <p className="mt-1 text-[11px] text-slate-400">{b.distance} away</p>
                      </div>
                      <div className="text-right">
                        <p className="font-display text-xl font-bold text-white">{b.bikes}</p>
                        <p className="text-[11px] text-slate-400">bikes · {b.docks} docks</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "ev" && (
              <div className="p-6">
                <div className="grid gap-3 sm:grid-cols-2">
                  {evStations.map((s) => (
                    <div key={s.name} className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition hover:border-lime-300/40">
                      <div className="flex items-start justify-between">
                        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-lime-300/15"><PlugZap className="h-5 w-5 text-lime-300" /></span>
                        <span className="rounded-full bg-white/10 px-2.5 py-1 text-[11px] font-bold text-white">{s.type}</span>
                      </div>
                      <p className="mt-3 text-sm font-bold text-white">{s.name}</p>
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-400"><Fuel className="h-3 w-3" /> {s.power} · solar-powered</p>
                      <div className="mt-3 flex items-center gap-2">
                        <div className="flex h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                          <div className="h-full rounded-full bg-gradient-to-r from-lime-400 to-emerald-400" style={{ width: `${(s.available / s.total) * 100}%` }} />
                        </div>
                        <span className="font-mono2 text-xs font-bold text-lime-300">{s.available}/{s.total}</span>
                      </div>
                      <button className="mt-3 w-full rounded-xl bg-white/10 py-2 text-xs font-bold text-white transition hover:bg-lime-300 hover:text-[#050914]">Reserve slot</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* side rail */}
          <div className="space-y-4">
            <div className="reveal reveal-delay-1 overflow-hidden rounded-3xl border border-white/10">
              <img src={cityImages.metro3} alt="Metro station" className="h-44 w-full object-cover" />
              <div className="bg-gradient-to-br from-[#0c1533] to-[#0a1230] p-5">
                <p className="font-mono2 text-[11px] tracking-[0.2em] text-cyan-300">CITYPASS</p>
                <p className="font-display mt-1 text-xl font-bold text-white">One tap. Every ride.</p>
                <p className="mt-1 text-sm text-slate-400">Metro, bus, bike, ferry & parking — capped at $6/day.</p>
                <div className="mt-4 flex gap-2">
                  <button className="flex-1 rounded-xl bg-gradient-to-r from-cyan-400 to-sky-500 py-2.5 text-sm font-bold text-[#050914]">Get CityPass</button>
                  <button className="flex-1 rounded-xl border border-white/15 py-2.5 text-sm font-semibold text-white">Fares</button>
                </div>
              </div>
            </div>
            <div className="reveal reveal-delay-2 glass rounded-3xl p-5">
              <p className="flex items-center gap-2 text-sm font-bold text-white"><CircleDot className="h-4 w-4 text-cyan-300" /> Airport Express</p>
              <div className="mt-3 space-y-2 text-sm">
                <div className="flex justify-between rounded-xl bg-white/[0.04] px-3 py-2"><span className="text-slate-300">Central → T1</span><span className="font-mono2 font-bold text-white">18 min</span></div>
                <div className="flex justify-between rounded-xl bg-white/[0.04] px-3 py-2"><span className="text-slate-300">Central → T2</span><span className="font-mono2 font-bold text-white">22 min</span></div>
                <div className="flex justify-between rounded-xl bg-white/[0.04] px-3 py-2"><span className="text-slate-300">Frequency</span><span className="font-mono2 font-bold text-lime-300">Every 8 min</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
