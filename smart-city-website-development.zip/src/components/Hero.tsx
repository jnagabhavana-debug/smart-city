import { useEffect, useState } from "react";
import { ArrowRight, TrainFront, HeartPulse, GraduationCap, ShieldAlert, MapPin, Sparkles, PlayCircle, ChevronRight } from "lucide-react";
import { cityImages } from "../data/cityData";

const quickActions = [
  { icon: TrainFront, label: "Live Transit", sub: "Metro · Bus · Bike", href: "#transport", color: "from-cyan-400 to-sky-600" },
  { icon: HeartPulse, label: "Find Hospital", sub: "ER waits live", href: "#health", color: "from-rose-400 to-red-600" },
  { icon: GraduationCap, label: "Schools", sub: "Admissions open", href: "#education", color: "from-violet-400 to-purple-600" },
  { icon: ShieldAlert, label: "Emergency", sub: "SOS · Alerts", href: "#emergency", color: "from-amber-400 to-orange-600" },
];

export default function Hero() {
  const [activeSlide, setActiveSlide] = useState(0);
  const slides = [cityImages.hero, cityImages.dubai, cityImages.skyline2];
  useEffect(() => {
    const t = setInterval(() => setActiveSlide((s) => (s + 1) % slides.length), 7000);
    return () => clearInterval(t);
  }, []);

  return (
    <section id="top" className="relative overflow-hidden">
      {/* BG */}
      <div className="absolute inset-0">
        {slides.map((src, i) => (
          <img key={i} src={src} alt="Smart city" className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-[2000ms] ${i === activeSlide ? "opacity-100" : "opacity-0"}`} />
        ))}
        <div className="absolute inset-0 bg-gradient-to-b from-[#050914]/85 via-[#050914]/72 to-[#050914]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050914]/85 via-transparent to-[#050914]/40" />
        <div className="bg-grid bg-grid-fade absolute inset-0 opacity-60" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-14 sm:px-6 lg:pt-20">
        <div className="grid items-center gap-10 lg:grid-cols-[1.15fr_0.85fr]">
          {/* Left */}
          <div>
            <div className="reveal inline-flex items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-cyan-200 backdrop-blur">
              <Sparkles className="h-3.5 w-3.5" />
              WORLD'S TOP 5 SMARTEST CITY · 2026 INDEX
              <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </div>
            <h1 className="reveal font-display mt-5 text-5xl font-bold leading-[1.02] tracking-tight text-white sm:text-6xl lg:text-7xl">
              One city.
              <br />
              <span className="bg-gradient-to-r from-cyan-300 via-sky-400 to-violet-400 bg-clip-text text-transparent">Every service.</span>
              <br />
              Zero queues.
            </h1>
            <p className="reveal reveal-delay-1 mt-5 max-w-xl text-[16px] leading-relaxed text-slate-300">
              Welcome to <span className="font-semibold text-white">Novapolis</span> — where metro arrivals, ER wait times, school admissions, utility bills and emergency alerts live in one intelligent portal. Built for <span className="text-cyan-300">2.48 million</span> residents.
            </p>
            <div className="reveal reveal-delay-2 mt-7 flex flex-wrap items-center gap-3">
              <a href="#services" className="group flex items-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-400 to-sky-500 px-6 py-3.5 text-[15px] font-bold text-[#050914] shadow-xl shadow-cyan-500/30 transition hover:shadow-cyan-400/50">
                Access 240+ Services <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </a>
              <a href="#stats" className="glass flex items-center gap-2 rounded-2xl px-6 py-3.5 text-[15px] font-semibold text-white transition hover:border-cyan-400/50">
                <PlayCircle className="h-5 w-5 text-cyan-300" /> City in numbers
              </a>
            </div>
            {/* live mini stats */}
            <div className="reveal reveal-delay-3 mt-8 grid max-w-xl grid-cols-3 gap-3">
              {[
                { k: "AQI NOW", v: "32 Good", c: "text-emerald-300" },
                { k: "METRO PULSE", v: "96% on-time", c: "text-cyan-300" },
                { k: "GRID", v: "78% green", c: "text-lime-300" },
              ].map((s) => (
                <div key={s.k} className="glass rounded-2xl px-4 py-3">
                  <p className="font-mono2 text-[10px] tracking-[0.18em] text-slate-400">{s.k}</p>
                  <p className={`font-display mt-1 text-lg font-bold ${s.c}`}>{s.v}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right — command card */}
          <div className="reveal reveal-delay-2">
            <div className="glass-strong relative overflow-hidden rounded-3xl p-6 shadow-2xl">
              <div className="absolute inset-x-0 top-0 h-1 shimmer-line" />
              <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-cyan-500/20 blur-3xl" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="animate-pulse-dot h-2.5 w-2.5 rounded-full bg-red-400" />
                  <p className="font-mono2 text-xs tracking-[0.2em] text-slate-300">CITY COMMAND · LIVE</p>
                </div>
                <span className="rounded-full bg-emerald-400/10 px-2.5 py-1 text-[11px] font-bold text-emerald-300 ring-1 ring-emerald-400/30">STABLE</span>
              </div>

              <div className="mt-5 space-y-3">
                {[
                  { line: "M1 Azure", dest: "Central Hub → Harborfront", eta: "2 min", w: "88%", col: "bg-cyan-400" },
                  { line: "M3 Violet", dest: "Hillcrest → Southport", eta: "4 min", w: "64%", col: "bg-violet-400" },
                  { line: "B07 Express", dest: "Old Town → Airport T1", eta: "6 min", w: "52%", col: "bg-amber-400" },
                ].map((r) => (
                  <div key={r.line} className="rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-semibold text-white">{r.line}</span>
                      <span className="font-mono2 rounded-md bg-white/10 px-2 py-0.5 text-xs font-bold text-lime-300">{r.eta}</span>
                    </div>
                    <p className="mt-0.5 text-xs text-slate-400">{r.dest}</p>
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10">
                      <div className={`h-full rounded-full ${r.col}`} style={{ width: r.w }} />
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                  <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">ER avg. wait</p>
                  <p className="font-display text-2xl font-bold text-white">11 <span className="text-sm font-medium text-slate-400">min</span></p>
                  <p className="text-[11px] text-emerald-300">↓ 34% with AI triage</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3.5">
                  <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">Bikes free</p>
                  <p className="font-display text-2xl font-bold text-white">1,240</p>
                  <p className="text-[11px] text-cyan-300">92 stations active</p>
                </div>
              </div>

              <a href="#transport" className="mt-4 flex items-center justify-center gap-1 rounded-xl border border-cyan-400/30 bg-cyan-400/10 py-2.5 text-sm font-semibold text-cyan-200 transition hover:bg-cyan-400/20">
                Open live transit board <ChevronRight className="h-4 w-4" />
              </a>
            </div>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-slate-500">
              <MapPin className="h-3.5 w-3.5" /> Central Hub, Novapolis · 12 districts connected
            </p>
          </div>
        </div>

        {/* Quick actions */}
        <div className="mt-12 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {quickActions.map((a, i) => (
            <a key={a.label} href={a.href} className={`reveal ${i === 1 ? "reveal-delay-1" : i === 2 ? "reveal-delay-2" : i === 3 ? "reveal-delay-3" : ""} group glass card-glow flex items-center gap-3.5 rounded-2xl p-4 transition`}>
              <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${a.color} shadow-lg`}>
                <a.icon className="h-5 w-5 text-white" />
              </span>
              <span>
                <span className="block text-[15px] font-bold text-white group-hover:text-cyan-200">{a.label}</span>
                <span className="block text-xs text-slate-400">{a.sub}</span>
              </span>
              <ArrowRight className="ml-auto h-4 w-4 text-slate-500 transition group-hover:translate-x-1 group-hover:text-cyan-300" />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
