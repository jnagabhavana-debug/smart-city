import { useState } from "react";
import { GraduationCap, Star, Users, BookOpen, Library, ArrowRight, Award, CalendarCheck } from "lucide-react";
import { schools, libraries, cityImages } from "../data/cityData";

const categories = ["All", "University", "K-12", "Medical", "Arts", "Business"];

export default function Education() {
  const [cat, setCat] = useState("All");
  const filtered = cat === "All" ? schools : schools.filter((s) => s.category === cat);

  return (
    <section id="education" className="relative py-20">
      <div className="pointer-events-none absolute left-0 top-32 h-80 w-80 rounded-full bg-violet-500/10 blur-3xl" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="reveal flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono2 text-xs tracking-[0.25em] text-violet-300">04 · LEARN & GROW</p>
            <h2 className="font-display mt-2 text-3xl font-bold text-white sm:text-4xl">Education for every age</h2>
            <p className="mt-2 max-w-xl text-slate-400">148 schools · 9 universities · 32 libraries. Admissions 2027–28 now open via CityPass.</p>
          </div>
          <button className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-violet-400 to-purple-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-violet-500/30 transition hover:brightness-110">
            <CalendarCheck className="h-4 w-4" /> Apply for 2027 admissions
          </button>
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[380px_1fr]">
          {/* Feature panel */}
          <div className="reveal relative overflow-hidden rounded-3xl border border-white/10">
            <img src={cityImages.library1} alt="Library" className="h-56 w-full object-cover" />
            <div className="bg-gradient-to-b from-[#101736] to-[#0a1230] p-6">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-violet-400/15 px-3 py-1 text-[11px] font-bold text-violet-200"><Award className="h-3.5 w-3.5" /> #1 STUDENT CITY · REGION</span>
              <h3 className="font-display mt-3 text-2xl font-bold text-white">Learn free. Learn anywhere.</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-300">Every resident gets free library access, 200+ online courses and makerspace credits. Literacy rate <span className="font-bold text-white">99.1%</span>.</p>
              <div className="mt-5 grid grid-cols-3 gap-2 text-center">
                {[{ v: "52K", l: "Uni seats" }, { v: "148", l: "Schools" }, { v: "32", l: "Libraries" }].map((s) => (
                  <div key={s.l} className="rounded-2xl bg-white/[0.05] p-3 ring-1 ring-white/10">
                    <p className="font-display text-lg font-bold text-white">{s.v}</p>
                    <p className="text-[11px] text-slate-400">{s.l}</p>
                  </div>
                ))}
              </div>
              <img src={cityImages.library2} alt="Students" className="mt-4 h-36 w-full rounded-2xl object-cover" />
            </div>
          </div>

          {/* list */}
          <div>
            <div className="reveal flex gap-2 overflow-x-auto no-scrollbar">
              {categories.map((c) => (
                <button key={c} onClick={() => setCat(c)} className={`shrink-0 rounded-xl px-4 py-2.5 text-[13px] font-bold transition ${cat === c ? "bg-violet-400 text-[#0a0a1a]" : "glass text-slate-300 hover:text-white"}`}>{c}</button>
              ))}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {filtered.map((s, i) => (
                <div key={s.id} className={`reveal ${i % 2 === 1 ? "reveal-delay-1" : ""} glass card-glow group rounded-2xl p-5`}>
                  <div className="flex items-start justify-between">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/30 to-fuchsia-500/20 ring-1 ring-white/10"><GraduationCap className="h-5 w-5 text-violet-200" /></span>
                    <span className="rounded-full bg-lime-300/15 px-2.5 py-1 text-[11px] font-bold text-lime-200">{s.tag}</span>
                  </div>
                  <h3 className="font-display mt-3 text-[16px] font-bold text-white group-hover:text-violet-200">{s.name}</h3>
                  <div className="mt-2 flex items-center gap-3 text-xs text-slate-400">
                    <span className="rounded-md bg-white/10 px-2 py-0.5 font-bold text-slate-200">{s.category}</span>
                    <span className="flex items-center gap-1 font-bold text-amber-300"><Star className="h-3 w-3 fill-amber-300" /> {s.rating}</span>
                  </div>
                  <div className="mt-3 flex items-center gap-4 text-xs text-slate-400">
                    <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {s.students.toLocaleString()} students</span>
                    <span className="flex items-center gap-1"><BookOpen className="h-3.5 w-3.5" /> {s.programs} programs</span>
                  </div>
                  <button className="mt-3 flex w-full items-center justify-center gap-1 rounded-xl bg-white/[0.06] py-2 text-[13px] font-bold text-white transition group-hover:bg-violet-400 group-hover:text-[#0a0a1a]">View programs <ArrowRight className="h-3.5 w-3.5" /></button>
                </div>
              ))}
            </div>

            {/* libraries */}
            <div className="reveal mt-4 grid gap-3 sm:grid-cols-3">
              {libraries.map((l) => (
                <div key={l.name} className="rounded-2xl border border-violet-400/20 bg-violet-500/[0.07] p-4">
                  <Library className="h-5 w-5 text-violet-300" />
                  <p className="mt-2 text-sm font-bold text-white">{l.name}</p>
                  <p className="text-xs text-slate-400">{l.books}</p>
                  <div className="mt-2 flex items-center justify-between text-[11px]">
                    <span className="text-violet-200">{l.hours}</span>
                    <span className="font-mono2 text-slate-500">{l.visitors}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
