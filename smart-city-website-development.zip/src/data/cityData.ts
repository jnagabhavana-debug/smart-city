export const cityImages = {
  hero: "https://images.pexels.com/photos/12343402/pexels-photo-12343402.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  skyline2: "https://images.pexels.com/photos/11720355/pexels-photo-11720355.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  tokyo: "https://images.pexels.com/photos/30993363/pexels-photo-30993363.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  metro1: "https://images.pexels.com/photos/15921368/pexels-photo-15921368.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  metro2: "https://images.pexels.com/photos/16086408/pexels-photo-16086408.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  metro3: "https://images.pexels.com/photos/8552477/pexels-photo-8552477.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  hospital: "https://images.pexels.com/photos/32134727/pexels-photo-32134727.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  building: "https://images.pexels.com/photos/18587786/pexels-photo-18587786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  library1: "https://images.pexels.com/photos/16420473/pexels-photo-16420473.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  library2: "https://images.pexels.com/photos/8199762/pexels-photo-8199762.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bikes: "https://images.pexels.com/photos/7706516/pexels-photo-7706516.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  park: "https://images.pexels.com/photos/36419292/pexels-photo-36419292.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  dubai: "https://images.pexels.com/photos/33687833/pexels-photo-33687833.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

export const tickerAlerts = [
  { tag: "METRO", text: "Line M2 running with 3-min delays near Central Hub — shuttle buses deployed", tone: "amber" },
  { tag: "WEATHER", text: "Clear skies, 24°C — excellent air quality (AQI 32) across all districts", tone: "green" },
  { tag: "EVENT", text: "Novapolis Tech Week starts Friday at Innovation Dome — free entry with CityPass", tone: "cyan" },
  { tag: "ROAD", text: "Harbor Bridge maintenance 11PM–4AM — use Riverside Express detour", tone: "amber" },
  { tag: "HEALTH", text: "Mobile vaccination units at Meridian Park & Old Town Square this weekend", tone: "green" },
  { tag: "POWER", text: "Grid stable — 78% renewable supply right now, solar peak at 1PM", tone: "cyan" },
];

export const cityStats = [
  { label: "Population", value: 2485000, suffix: "", format: "m", display: "2.48M", sub: "+3.2% YoY growth", icon: "users" },
  { label: "Green Coverage", value: 42, suffix: "%", display: "42%", sub: "680 parks & corridors", icon: "leaf" },
  { label: "Public Transit Share", value: 68, suffix: "%", display: "68%", sub: "1.9M daily riders", icon: "train" },
  { label: "Renewable Energy", value: 78, suffix: "%", display: "78%", sub: "Solar + wind + hydro", icon: "zap" },
  { label: "Safety Index", value: 94, suffix: "/100", display: "94", sub: "Top 5 safest globally", icon: "shield" },
  { label: "Digital Services", value: 240, suffix: "+", display: "240+", sub: "100% online access", icon: "wifi" },
];

export const populationGrowth = [
  { year: "2018", pop: 1.82 },
  { year: "2019", pop: 1.94 },
  { year: "2020", pop: 2.02 },
  { year: "2021", pop: 2.14 },
  { year: "2022", pop: 2.27 },
  { year: "2023", pop: 2.36 },
  { year: "2024", pop: 2.42 },
  { year: "2025", pop: 2.48 },
];

export const energyMix = [
  { label: "Solar", value: 38, color: "#facc15" },
  { label: "Wind", value: 27, color: "#22d3ee" },
  { label: "Hydro", value: 13, color: "#3b82f6" },
  { label: "Nuclear", value: 14, color: "#a78bfa" },
  { label: "Gas", value: 8, color: "#64748b" },
];

export const trafficByHour = [
  { h: "6a", v: 22 }, { h: "7a", v: 55 }, { h: "8a", v: 88 }, { h: "9a", v: 72 },
  { h: "10a", v: 45 }, { h: "12p", v: 52 }, { h: "2p", v: 48 }, { h: "4p", v: 64 },
  { h: "6p", v: 92 }, { h: "8p", v: 58 }, { h: "10p", v: 28 }, { h: "12a", v: 12 },
];

export type MetroLine = {
  id: string;
  name: string;
  color: string;
  status: "on-time" | "delayed" | "maintenance";
  statusText: string;
  stations: string[];
  frequency: string;
};

export const metroLines: MetroLine[] = [
  { id: "M1", name: "Azure Line", color: "#22d3ee", status: "on-time", statusText: "On time", stations: ["Northgate", "University", "Meridian Park", "Central Hub", "Old Town", "Harborfront"], frequency: "Every 3 min" },
  { id: "M2", name: "Emerald Line", color: "#4ade80", status: "delayed", statusText: "3 min delay", stations: ["Westfield", "Innovation Dome", "Central Hub", "Riverside", "Airport T1", "Airport T2"], frequency: "Every 5 min" },
  { id: "M3", name: "Violet Line", color: "#a78bfa", status: "on-time", statusText: "On time", stations: ["Hillcrest", "Museum Quarter", "Civic Center", "Central Hub", "Lakeside", "Southport"], frequency: "Every 4 min" },
  { id: "M4", name: "Amber Loop", color: "#fbbf24", status: "maintenance", statusText: "Night works 11PM–4AM", stations: ["Central Hub", "Stadium", "Tech Park", "Green Valley", "Harbor Bridge", "Central Hub"], frequency: "Every 7 min" },
];

export const busRoutes = [
  { id: "B12", from: "Central Hub", to: "Northgate", eta: [2, 9, 17], occupancy: "Moderate", color: "#22d3ee" },
  { id: "B34", from: "Harborfront", to: "Tech Park", eta: [4, 12, 21], occupancy: "Low", color: "#4ade80" },
  { id: "B07", from: "Old Town", to: "Airport T1", eta: [1, 8, 15], occupancy: "High", color: "#a78bfa" },
  { id: "B51", from: "Lakeside", to: "University", eta: [6, 14, 23], occupancy: "Moderate", color: "#fbbf24" },
  { id: "N02", from: "Central Hub", to: "Southport", eta: [9, 24, 39], occupancy: "Low", color: "#f472b6" },
];

export const bikeStations = [
  { name: "Central Hub Plaza", bikes: 24, docks: 6, distance: "0.1 km" },
  { name: "Meridian Park East", bikes: 18, docks: 12, distance: "0.8 km" },
  { name: "University Gate 2", bikes: 7, docks: 23, distance: "1.2 km" },
  { name: "Harborfront Pier", bikes: 31, docks: 4, distance: "1.9 km" },
  { name: "Museum Quarter", bikes: 12, docks: 18, distance: "2.4 km" },
];

export const evStations = [
  { name: "Civic Center Garage L2", available: 8, total: 16, power: "150 kW", type: "Fast DC" },
  { name: "Tech Park Solar Hub", available: 12, total: 20, power: "350 kW", type: "Ultra" },
  { name: "Harborfront Deck", available: 3, total: 10, power: "50 kW", type: "Standard" },
  { name: "Northgate Mall P1", available: 6, total: 12, power: "150 kW", type: "Fast DC" },
];

export type Hospital = {
  id: number;
  name: string;
  type: string;
  district: string;
  rating: number;
  erWait: number;
  beds: number;
  availableBeds: number;
  specialties: string[];
  phone: string;
  open24: boolean;
  trauma: boolean;
};

export const hospitals: Hospital[] = [
  { id: 1, name: "Novapolis General Hospital", type: "Public · Level-1 Trauma", district: "Civic Center", rating: 4.9, erWait: 12, beds: 850, availableBeds: 64, specialties: ["Cardiology", "Neurology", "Trauma", "Oncology"], phone: "+1 (555) 010-2000", open24: true, trauma: true },
  { id: 2, name: "Meridian Children's Hospital", type: "Specialist · Pediatric", district: "Meridian", rating: 4.8, erWait: 8, beds: 320, availableBeds: 41, specialties: ["Pediatrics", "Neonatal", "Surgery"], phone: "+1 (555) 010-3400", open24: true, trauma: false },
  { id: 3, name: "Harborview Medical Center", type: "Private · Multi-specialty", district: "Harborfront", rating: 4.7, erWait: 18, beds: 410, availableBeds: 22, specialties: ["Orthopedics", "Cardiology", "Diagnostics"], phone: "+1 (555) 010-5100", open24: true, trauma: false },
  { id: 4, name: "Tech Park Smart Clinic", type: "Clinic · AI Diagnostics", district: "Tech Park", rating: 4.6, erWait: 5, beds: 60, availableBeds: 18, specialties: ["AI Screening", "Dermatology", "Telehealth"], phone: "+1 (555) 010-7700", open24: false, trauma: false },
  { id: 5, name: "Lakeside Community Hospital", type: "Public · Community", district: "Lakeside", rating: 4.5, erWait: 15, beds: 240, availableBeds: 35, specialties: ["Family Care", "Maternity", "Geriatrics"], phone: "+1 (555) 010-8800", open24: true, trauma: false },
  { id: 6, name: "St. Aurora Heart Institute", type: "Specialist · Cardiac", district: "Old Town", rating: 4.9, erWait: 10, beds: 180, availableBeds: 12, specialties: ["Cardiac Surgery", "Vascular", "Rehab"], phone: "+1 (555) 010-9900", open24: true, trauma: false },
];

export const schools = [
  { id: 1, name: "Novapolis Institute of Technology", category: "University", students: 28400, rating: 4.9, programs: 120, tag: "Rank #12 Global", image: "tech" },
  { id: 2, name: "Meridian International School", category: "K-12", students: 3200, rating: 4.8, programs: 45, tag: "IB World School", image: "k12" },
  { id: 3, name: "Civic Arts & Design Academy", category: "Arts", students: 5400, rating: 4.7, programs: 38, tag: "Design Excellence", image: "arts" },
  { id: 4, name: "Harbor Medical University", category: "Medical", students: 9100, rating: 4.9, programs: 64, tag: "Research Leader", image: "med" },
  { id: 5, name: "Green Valley STEM High", category: "K-12", students: 1800, rating: 4.6, programs: 28, tag: "Robotics Champs", image: "stem" },
  { id: 6, name: "Lakeside Business School", category: "Business", students: 6700, rating: 4.7, programs: 42, tag: "Top 20 MBA", image: "biz" },
];

export const libraries = [
  { name: "Central Grand Library", books: "2.4M volumes", hours: "7AM – 11PM", visitors: "8.2K/day" },
  { name: "Tech Park Digital Hub", books: "Full digital + makerspace", hours: "24/7 smart access", visitors: "3.1K/day" },
  { name: "Old Town Heritage Archive", books: "Rare manuscripts", hours: "9AM – 6PM", visitors: "1.4K/day" },
];

export const publicServices = [
  { id: "water", title: "Water & Utilities", desc: "Bills, leaks, quality reports & new connections", icon: "droplets", status: "Operational", statusTone: "green", requests24h: 184 },
  { id: "power", title: "Power & Grid", desc: "Outages, solar net-metering & smart meters", icon: "zap", status: "Operational", statusTone: "green", requests24h: 96 },
  { id: "waste", title: "Waste & Recycling", desc: "Pickup schedules, e-waste & composting", icon: "recycle", status: "Operational", statusTone: "green", requests24h: 342 },
  { id: "permits", title: "Permits & Licenses", desc: "Building, business & event permits online", icon: "file", status: "High demand", statusTone: "amber", requests24h: 512 },
  { id: "roads", title: "Roads & Streets", desc: "Potholes, lighting, signage & repairs", icon: "road", status: "Operational", statusTone: "green", requests24h: 228 },
  { id: "tax", title: "Tax & Finance", desc: "Property tax, refunds & payment plans", icon: "wallet", status: "Operational", statusTone: "green", requests24h: 167 },
  { id: "housing", title: "Housing & Rent", desc: "Affordable housing, aid & registration", icon: "home", status: "Operational", statusTone: "green", requests24h: 203 },
  { id: "parks", title: "Parks & Environment", desc: "Tree care, park bookings & green drives", icon: "leaf", status: "Operational", statusTone: "green", requests24h: 141 },
];

export const emergencyContacts = [
  { name: "Police", number: "911", desc: "Crime, theft, public safety", icon: "shield", color: "#3b82f6" },
  { name: "Fire & Rescue", number: "912", desc: "Fire, gas leak, rescue", icon: "flame", color: "#f97316" },
  { name: "Ambulance", number: "913", desc: "Medical emergency", icon: "cross", color: "#ef4444" },
  { name: "Disaster Control", number: "914", desc: "Flood, quake, evacuation", icon: "alert", color: "#facc15" },
  { name: "Women & Child Helpline", number: "915", desc: "24/7 support & shelter", icon: "heart", color: "#f472b6" },
  { name: "Tourist Police", number: "916", desc: "Multilingual assistance", icon: "globe", color: "#22d3ee" },
];

export const incidents = [
  { id: "INC-2481", type: "Traffic", location: "Harbor Bridge, Lane 2", time: "12 min ago", severity: "Moderate", status: "Responding", color: "#fbbf24" },
  { id: "INC-2479", type: "Medical", location: "Meridian Park Gate B", time: "26 min ago", severity: "High", status: "On scene", color: "#ef4444" },
  { id: "INC-2475", type: "Fire", location: "Old Town, Baker St 44", time: "1 h ago", severity: "Contained", status: "Monitoring", color: "#4ade80" },
  { id: "INC-2471", type: "Utility", location: "Tech Park, Sector 7", time: "2 h ago", severity: "Low", status: "Resolved", color: "#22d3ee" },
];

export type Place = {
  id: number;
  name: string;
  category: "Landmark" | "Culture" | "Nature" | "Government" | "Shopping" | "Worship";
  district: string;
  rating: number;
  open: string;
  desc: string;
  tags: string[];
};

export const places: Place[] = [
  { id: 1, name: "Sky Needle Observatory", category: "Landmark", district: "Central Hub", rating: 4.9, open: "9AM – 11PM", desc: "382m tower with 360° glass deck, AR city guide & sky restaurant.", tags: ["Must-see", "Family"] },
  { id: 2, name: "Innovation Dome", category: "Culture", district: "Tech Park", rating: 4.8, open: "10AM – 8PM", desc: "Immersive science museum with robotics lab, planetarium & VR zones.", tags: ["Tech", "Kids"] },
  { id: 3, name: "Meridian Grand Park", category: "Nature", district: "Meridian", rating: 4.9, open: "5AM – 11PM", desc: "240-hectare urban forest with lakes, cycling loops & botanical garden.", tags: ["Green", "Sports"] },
  { id: 4, name: "City Hall & Civic Plaza", category: "Government", district: "Civic Center", rating: 4.7, open: "8AM – 6PM", desc: "Neo-futurist civic headquarters with public gallery & citizen desk.", tags: ["Services", "Tours"] },
  { id: 5, name: "Old Town Heritage Market", category: "Shopping", district: "Old Town", rating: 4.8, open: "9AM – 10PM", desc: "Historic bazaar with 400+ artisan stalls, food halls & night market.", tags: ["Food", "Crafts"] },
  { id: 6, name: "Museum of Light", category: "Culture", district: "Museum Quarter", rating: 4.9, open: "10AM – 9PM", desc: "Digital art museum famous for its immersive light-tunnel exhibits.", tags: ["Art", "Photo"] },
  { id: 7, name: "Harborfront Promenade", category: "Landmark", district: "Harborfront", rating: 4.7, open: "24 Hours", desc: "6km waterfront with ferries, street food, marina & sunset decks.", tags: ["Views", "Walk"] },
  { id: 8, name: "Lakeside Sanctuary", category: "Nature", district: "Lakeside", rating: 4.8, open: "6AM – 8PM", desc: "Bird sanctuary & wetlands with boardwalks and sunrise kayaking.", tags: ["Wildlife", "Calm"] },
  { id: 9, name: "Grand Central Mosque & Interfaith Center", category: "Worship", district: "Civic Center", rating: 4.9, open: "5AM – 10PM", desc: "Architectural icon welcoming all faiths with gardens & library.", tags: ["Peace", "Tours"] },
];

export const districts = [
  { id: "northgate", name: "Northgate", x: 52, y: 12, pop: "310K", desc: "University & research corridor with green campuses.", aqi: 28, transit: "M1 · B12 · B51" },
  { id: "techpark", name: "Tech Park", x: 74, y: 26, pop: "180K", desc: "Innovation district — startups, labs & data centers.", aqi: 35, transit: "M4 · B34" },
  { id: "meridian", name: "Meridian", x: 30, y: 30, pop: "420K", desc: "Family district around the Grand Park & schools.", aqi: 24, transit: "M1 · B07" },
  { id: "central", name: "Central Hub", x: 50, y: 46, pop: "390K", desc: "Downtown core — business, transit interchange & towers.", aqi: 41, transit: "M1 M2 M3 M4" },
  { id: "civic", name: "Civic Center", x: 62, y: 48, pop: "150K", desc: "Government & courts, hospitals & grand library.", aqi: 33, transit: "M3 · B12" },
  { id: "museum", name: "Museum Quarter", x: 42, y: 60, pop: "120K", desc: "Arts, galleries, theatres & riverside cafés.", aqi: 30, transit: "M3 · B51" },
  { id: "oldtown", name: "Old Town", x: 26, y: 62, pop: "210K", desc: "Heritage streets, markets & boutique hotels.", aqi: 38, transit: "M1 · B07" },
  { id: "harbor", name: "Harborfront", x: 58, y: 74, pop: "260K", desc: "Port, promenade, seafood & ferry terminals.", aqi: 29, transit: "M1 · Ferry" },
  { id: "lakeside", name: "Lakeside", x: 78, y: 66, pop: "240K", desc: "Eco residential zone with lakes & wetlands.", aqi: 22, transit: "M3 · B51" },
  { id: "southport", name: "Southport", x: 46, y: 88, pop: "205K", desc: "Logistics & airport link with new housing.", aqi: 36, transit: "M3 · N02" },
];

export const news = [
  { id: 1, tag: "Infrastructure", title: "Metro M5 'Coral Line' approved — 18 new stations by 2028", date: "Nov 20, 2026", read: "4 min read" },
  { id: 2, tag: "Environment", title: "City hits 78% renewable power — new solar park goes live", date: "Nov 18, 2026", read: "3 min read" },
  { id: 3, tag: "Health", title: "AI triage cuts ER wait times by 34% across public hospitals", date: "Nov 15, 2026", read: "5 min read" },
  { id: 4, tag: "Culture", title: "Festival of Lights returns to Old Town with drone sky-show", date: "Nov 12, 2026", read: "2 min read" },
];
